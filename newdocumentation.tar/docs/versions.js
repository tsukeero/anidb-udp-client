"use strict"
export const DOC_VERSIONS = [
	'stable',
	'v1.0',
];
