"use strict"
export const DOC_VERSIONS = [
	'stable',
	'v1.1',
	'v1.0',
];
